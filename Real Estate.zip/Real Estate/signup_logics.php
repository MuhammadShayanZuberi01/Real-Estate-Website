<?php
// Establishing connection to the database
$conn = mysqli_connect("localhost", "root", "", "skyestate");

// Checking the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieving form data
if(isset($_POST['submit'])) {
    $username = mysqli_real_escape_string($conn, $_POST['user']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['pass']);
    $confirmPassword = mysqli_real_escape_string($conn, $_POST['cpass']);
    
    // Perform validation
    // You can add more validation as per your requirements
    
    // Check if passwords match
    if($password !== $confirmPassword) {
        // Passwords do not match, redirect with error message
        header("Location: http://localhost/Real Estate/signup.php?message=passwords_not_match");
        exit();
    }
    
    // Check if username already exists
    $checkUsernameQuery = "SELECT * FROM `signup` WHERE username='$username'";
    $resultUsername = mysqli_query($conn, $checkUsernameQuery);
    if(mysqli_num_rows($resultUsername) > 0) {
        // Username already exists, redirect with error message
        header("Location: http://localhost/Real Estate/signup.php?message=username_exists");
        exit();
    }

    // Check if email already exists
    $checkEmailQuery = "SELECT * FROM `signup` WHERE email='$email'";
    $resultEmail = mysqli_query($conn, $checkEmailQuery);
    if(mysqli_num_rows($resultEmail) > 0) {
        // Email already exists, redirect with error message
        header("Location: http://localhost/Real Estate/signup.php?message=email_exists");
        exit();
    }
    
    // Hashing the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Inserting data into the database
    $sql = "INSERT INTO `signup` (`id`, `username`, `email`, `password`) VALUES (NULL, '{$username}', '{$email}', '{$hashedPassword}');";
    if(mysqli_query($conn, $sql)) {
        // Redirect to loginform.php after successful signup with success message
        header("Location: http://localhost/Real Estate/login.php?message=signup_success");
        exit(); // Ensure that subsequent code is not executed after redirection
    } else {
        // Error in inserting data, redirect with error message
        header("Location: http://localhost/Real Estate/signup.php?message=signup_error");
        exit();
    }
}

// Closing the connection
mysqli_close($conn);
?>
