<?php

  $name = $_POST['name'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $message = $_POST['message'];

  $conn=mysqli_connect("localhost","root","","skyestate");

  $sql="INSERT INTO `contact` (`id`, `name`, `email`, `phone`, `message`) VALUES (NULL, '{$name}', '{$email}', '{$phone}', '{$message}');";
  
  // You can add more processing here, like sending the email to your inbox
  
  // For demonstration, simply echo the received data
 if(mysqli_query($conn,$sql)){
  header("Location: http://localhost/Real%20Estate/index.php");
 } else {
  echo "Data Not Found";
 }
?>
