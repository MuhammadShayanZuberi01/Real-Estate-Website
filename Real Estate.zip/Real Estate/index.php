<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Real Estate Website</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
  <link rel="shortcut icon" href="./images/Blue Abstract Illustrative Real Estate Property Logo.jpg">
  <style>
    /* Custom styles */
    /* You can add your own custom styles here */
    #right-image {
      width: 80%;
      /* Adjust the width as needed */
      border-top-left-radius: 200px;
      border-top-right-radius: 200px;
    }

    .bottom-right-image-container {
      position: relative;
    }

    .small-image {
      position: absolute;
      bottom: 0;
      right: -5px;
      bottom: -45px;
      width: 300px;
      /* Adjust the width of the small image as needed */
    }

    .navbar-light .navbar-nav .nav-link:focus, .navbar-light .navbar-nav .nav-link:hover{
      color: rgb(0, 119, 255); ;
    }
    .navbar-light .navbar-nav .nav-link {
    color: rgb(0 0 0);
}
.card {
      margin-bottom: 20px;
    }
  </style>
  </style>
</head>

<body>
  <!--Navbar start-->
  <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
    <div class="container">
      <a class="navbar-brand" href="">
        <img src="./images/Blue Abstract Illustrative Real Estate Property Logo.jpg" alt="Logo" width="50" height="50"
          class="d-inline-block align-text-top">
      </a>
      <a class="navbar-brand" href="#" style="font-weight: bold;">Sky Estate</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a class="nav-link" href="#home">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#product">Product</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#services">Services</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#contact">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#aboutus">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#support">Support Us</a>
          </li>
        </ul>
        <ul class="navbar-nav ml-auto">
        <?php if(isset($_COOKIE['PHPSESSID'])) { ?>
          <li class="nav-item mb-2 mb-md-0" style="margin-right: 10px;">
              <button type="button" class="btn btn-primary" style="display: none;"><a href="./signup.php" style="color: white; text-decoration: none;">Sign Up</a></button>
          </li>
          <li class="nav-item" style="margin-right: 10px;">
              <button type="button" class="btn btn-secondary" style="display: none;"><a href="./login.php" style="color: white; text-decoration: none;">Log In</a></button>
          </li>
            <?php } else { ?>
              <li class="nav-item mb-2 mb-md-0" style="margin-right: 10px;">
              <button type="button" class="btn btn-primary" style="border-radius: 20px;"><a href="./signup.php" style="color: white; text-decoration: none;">Sign Up</a></button>
          </li>
          <li class="nav-item" style="margin-right: 10px;">
              <button type="button" class="btn btn-secondary" style="border-radius: 20px;"><a href="./login.php" style="color: white; text-decoration: none;">Log In</a></button>
          </li>
            <?php } ?>
        
      </ul>
      </div>
    </div>
  </nav>
  <!--Navbar End-->

  <!--Home Start-->
  <div id="home" class="container py-5">
    <div class="row">
      <div class="col-md-6" style="padding-top: 100px;">
        <H1>Let's Find A Home That's Perfect For You
        </H1>
        <p>Each property design has its own meaning and we are ready to help you to get a property according to your
          taste</p>
        <p style="font-weight: bold;">Let's discuss soon</p>
        <div class="card text-center">
          <div class="card-body">
            <div class="row">
              <div class="col-md-4">
                <button type="button" class="btn btn-outline-primary">BUY</button>
              </div>
              <div class="col-md-4">
                <button type="button" class="btn btn-outline-primary">SELL</button>
              </div>
              <div class="col-md-4">
                <button type="button" class="btn btn-outline-primary">RENT</button>
              </div>
            </div>
            <br>
            <div class="row">
              <div class="col-md-4">
                <h7>Location</h7>
                <p style="font-weight: bold;">Pakistan, Karachi</p>
              </div>
              <div class="col-md-4">
                <h7>Style</h7>
                <p style="font-weight: bold;">Modern, Classic</p>
              </div>
              <div class="col-md-4">
                <button type="button" class="btn btn-outline-primary">SEARCH</button>
              </div>
            </div>
          </div>
        </div>
        <br>
        <!-- Our work counter Section Start    -->

        <section class="section section-work-data">
          <div id="product">
          <div class="container">
            <div class="row">
              <div class="col-md-4" style="background-color: rgba(169, 169, 169, 0.226);">
                <h2 class="counter-numbers" data-number="2000" style="color: rgb(0, 119, 255); ">9k+</h2>
                <p style="font-weight: bold; font-size: small;">Premium Properties</p>
              </div>
              <div class="col-md-4" style="background-color: rgba(127, 255, 212, 0.459);">
                <h2 class="counter-numbers" data-number="6000" style="color:rgb(0, 119, 255);">5k+</h2>
                <p style="font-weight: bold; font-size: small;">Happy Customers</p>
              </div>
              <div class="col-md-4" style="background-color: rgba(169, 169, 169, 0.226);">
                <h2 class="counter-numbers" data-number="5000" style="color: rgb(0, 119, 255);">55+</h2>
                <p style="font-weight: bold; font-size: small;">Awards Winning</p>
              </div>
            </div>
          </div>
        </div>
        </section>
        <!-- Our Services  Section End -->

        <!--Right picture section-->
      </div>
      <div class="col-md-6">
        <img id="right-image" src="./images/Top 10 Small House Design Ideas To Beautify Your Tiny Home in 2022.jpeg"
          alt="">
      </div>
    </div>
    <p></p>
  </div>
  <!--Right  picture section End-->
  <!--Home End-->

  <!--Properties Start-->
  <div id="properties" class="container py-5">
    <P style="text-align: center; font-size: xx-large; font-weight: bold;">What we do?</P>
    <p style="text-align: center;">Each property design has its own meaning and we are ready to help you to get a</p>
    <p style="text-align: center;">property according to your taste</p>
    <br>
    <div class="row">
      <div class="col-md-6 col-lg-3">
        <div class="container">
          <div class="card text-center">
            <div class="card-body">
              <i class="fa-solid fa-message fa-2x" style="color:  rgb(0, 119, 255);"></i>
              <h5 class="card-title" style="padding-top: 20px;">Communication</h5>
              <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus.</p>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-3">
        <div class="container">
          <div class="card text-center">
            <div class="card-body">
              <i class="fa-solid fa-shield fa-2x" style="color:  rgb(0, 119, 255);"></i>
              <h5 class="card-title " style="padding-top: 20px;">Reliability</h5>
              <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus.</p>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-3">
        <div class="container">
          <div class="card text-center">
            <div class="card-body">
              <i class="fa-solid fa-medal fa-2x" style="color:  rgb(0, 119, 255);"></i>
              <h5 class="card-title" style="padding-top: 20px;">Quality First</h5>
              <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus.</p>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-3">
        <div class="container">
          <div class="card text-center">
            <div class="card-body">
              <i class="fa-solid fa-people-group fa-2x" style="color:  rgb(0, 119, 255);"></i>
              <h5 class="card-title" style="padding-top: 20px;">Families</h5>
              <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--Properties End-->

  <!--Services Start-->
  <div id="services" class="container py-5">
    <p style="text-align: center; font-size: xx-large; font-weight: bold;">Best Properties Available</p>
    <p style="text-align: center;">Each property design has its own meaning and we are ready to help you to get a</p>
    <p style="text-align: center;">property according to your taste</p>
    <div class="container">
      <div class="row">
        <?php
         $conn=mysqli_connect("localhost","root","","skyestate");
         $sql="SELECT * FROM `houses`";

         $result=mysqli_query($conn,$sql);

         if(mysqli_num_rows($result) > 0){
          while($row=mysqli_fetch_assoc($result)){

        ?>
        <div class="col-md-4">
          <div class="top">
          <div class="box mb-4">
            <img src="<?php echo $row['h_img']?>" class="card-img-top" alt="...">
          </div>
            <div class="bottom">
              <h5 class="card-title"><?php echo $row['h_title']?></h5>
              <p class="card-text"><?php echo $row['h_details']?></p>
              <div class="row">
                <div class="col-sm-6">
                  <div class="advants">
                    <div>
                      <span>MasterRoom: </span>
                      <span><i class="fa-solid fa-door-open"></i> <?php echo $row['h_masterroom']?></span>
                    </div>
                    <div>
                      <span>Bedrooms: </span>
                      <span><i class="fa-solid fa-bed"></i> <?php echo $row['h_bedroom']?></span>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="advants">
                    <div>
                      <span>Bathroom: </span>
                      <span><i class="fa-solid fa-bath"></i> <?php echo $row['h_bathroom']?></span>
                    </div>
                    <div>
                      <span>Location: </span>
                      <span><i class="fa-solid fa-location-dot"></i> <?php echo $row['h_location']?></span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="price" style="font-weight: bold; margin-top: 10px;">
                <span style="margin-right: 140px;"><?php echo $row['h_price']?></span> 
                <button type="button" class="btn btn-primary btn-sm">See More</button>
              </div>
              
            </div>
            
            
          </div>
        </div>
        <?php
                  }
                } else {
                 echo "Data Not Found";
                }
        ?>
        <!-- <div class="col-md-4">
          <div class="top">
          <div class="box mb-4">
            <img src="./images/Jerome Drive - T_Griffiths Holdings.jpg" class="card-img-top" alt="...">
          </div>
            <div class="bottom">
              <h5 class="card-title">Best Property One</h5>
              <p class="card-text">Each property has its own meaning</p>
              <div class="row">
                <div class="col-sm-6">
                  <div class="advants">
                    <div>
                      <span>MasterRoom: </span>
                      <span><i class="fa-solid fa-door-open"></i> 3</span>
                    </div>
                    <div>
                      <span>Bedrooms: </span>
                      <span><i class="fa-solid fa-bed"></i> 3</span>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="advants">
                    <div>
                      <span>Bathroom: </span>
                      <span><i class="fa-solid fa-bath"></i> 3</span>
                    </div>
                    <div>
                      <span>Location: </span>
                      <span><i class="fa-solid fa-location-dot"></i> Gulshan</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="price" style="font-weight: bold; margin-top: 10px;">
                <span style="margin-right: 140px;">$95,000</span> 
                <button type="button" class="btn btn-primary btn-sm">See More</button>
              </div>
              
            </div>
            
            
          </div>
        </div>
        <div class="col-md-4">
          <div class="top">
          <div class="box mb-4">
            <img src="./images/How to choose the right facade for your forever home.jpg" class="card-img-top" alt="...">
          </div>
            <div class="bottom">
              <h5 class="card-title">Best Property One</h5>
              <p class="card-text">Each property has its own meaning</p>
              <div class="row">
                <div class="col-sm-6">
                  <div class="advants">
                    <div>
                      <span>MasterRoom: </span>
                      <span><i class="fa-solid fa-door-open"></i> 3</span>
                    </div>
                    <div>
                      <span>Bedrooms: </span>
                      <span><i class="fa-solid fa-bed"></i> 3</span>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="advants">
                    <div>
                      <span>Bathroom: </span>
                      <span><i class="fa-solid fa-bath"></i> 3</span>
                    </div>
                    <div>
                      <span>Location: </span>
                      <span><i class="fa-solid fa-location-dot"></i> Gulshan</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="price" style="font-weight: bold; margin-top: 10px;">
                <span style="margin-right: 140px;">$95,000</span> 
                <button type="button" class="btn btn-primary btn-sm">See More</button>
              </div>
              
            </div>
            
            
          </div>
        </div> -->
          </div>
        </div>
        <!-- Repeat the above code for each card -->
      </div>
    </div>
  </div>
  
  
      
      <!-- <div class="box">
        <div class="top">
          <img src="./images/Our Projects - M_ Lahr Homes.jfif" alt="" />
          <span></i></span>
        </div>
        <div class="bottom">
          <h3>Best Property One</h3>
          <p>
            Each property has its own meaning
          </p>
          <div class="advants">
            <div>
              <span>MasterRoom</span>
              <div><i class="fa-solid fa-door-open"></i><span>3</span></div>
            </div>
            <div>
              <span>Bedrooms</span>
              <div><i class="fa-solid fa-bed"></i><span>3</span></div>
            </div>
          </div>
          <div class="advants">
            <div>
              <span>Bathroom</span>
              <div><i class="fa-solid fa-bath"></i></i><span>3</span></div>
            </div>
            <div>
              <span>Location</span>
              <div><i class="fa-solid fa-location-dot"></i></i><span>Gulshan</span></div>
            </div>
          </div>
          <div class="price">
            <span>$95,000 <button type="button" class="btn btn-primary" style="margin-left: 50px;">See
                More</button></span>
          </div>
        </div>
        
      </div>
      <div class="box">
        <div class="top">
          <img src="./images/Jerome Drive - T_Griffiths Holdings.jfif" alt="" />
          <span></i></span>
        </div>
        <div class="bottom">
          <h3>Best Property One</h3>
          <p>
            Each property has its own meaning
          </p>
          <div class="advants">
            <div>
              <span>MasterRoom</span>
              <div><i class="fa-solid fa-door-open"></i><span>3</span></div>
            </div>
            <div>
              <span>Bedrooms</span>
              <div><i class="fa-solid fa-bed"></i><span>3</span></div>
            </div>
          </div>
          <div class="advants">
            <div>
              <span>Bathroom</span>
              <div><i class="fa-solid fa-bath"></i></i><span>3</span></div>
            </div>
            <div>
              <span>Location</span>
              <div><i class="fa-solid fa-location-dot"></i></i><span>Gulshan</span></div>
            </div>
          </div>
          <div class="price">
            <span>$95,000 <button type="button" class="btn btn-primary" style="margin-left: 50px;">See
                More</button></span>
          </div>
        </div>
        
      </div> -->
    </div>
    
  </div>
  </d iv>

  <!--Services End-->


  <!--Bottom Start-->
    <div id="Bottom" class="container py-5">
      <div class="row">
        <div class="col-md-6" style="padding-top: 120px;">
          <H1>We Are Ready To Make Your Dream Come True
          </H1>
          <p>Each property design has its own meaning and we are ready to help you to get a property according to your
            taste</p>
          <button type="button" class="btn btn-primary">See More</button>
        </div>
        <div class="col-md-6 bottom-right-image-container">
          <div style="position: relative;">
            <img id="bottom-right-image"
              src="./images/Like a bit of brick_ - Reiach and Hall administrative building in Scotland _ STYLEPARK.jpeg"
              alt="" class="img-fluid">
            <img src="./images/W99 Amsterdam - Hund Falk Architecten.jpeg" alt="" class="small-image">
          </div>
        </div>
      </div>
      <p></p>
    </div>
    <!--Bottom End-->
    <br>
    <!---Contact Us-->
    <section id="contact">
      <div class="container text-center">
        <div class="row align-items-start">
            <div class="col">
                <div class="fs-2">
                    <div style="font-weight: bold; color:  rgb(0, 119, 255);">
                        INQURY
                    </div>
                </div>
            </div>
        </div>
      </div>
            <div class="container text-center">
                <div class="row align-items-start">
                    <div class="col">
                        <div class="fs-1">
                            <div class="text-SUCCES" style="font-weight: bold;">
                                GET IN TOUCH
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                    <br>
                    <div class="container text-center">
                        <div class="row align-items-start">
                          <form style="width: 100%;" action="contact.php" method="post">
                            <div class="card" style="width: 100%;">
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label for="exampleFormControlInput1" class="form-label">Name</label>
                                        <input type="name" name="name" class="form-control" id="exampleFormControlInput1"
                                            placeholder="nameexample" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleFormControlInput1" class="form-label">Email address</label>
                                        <input type="email" name="email" class="form-control" id="exampleFormControlInput1"
                                            placeholder="name@example.com" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleFormControlInput1" class="form-label">Phone</label>
                                        <input type="phone" name="phone" class="form-control" id="exampleFormControlInput1"
                                            placeholder="0123-4567890">
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleFormControlTextarea1" class="form-label">Your Message</label>
                                        <textarea class="form-control" name="message" id="exampleFormControlTextarea1"
                                            rows="5"></textarea>
                                            <br>
                                            <button type="submit" class="btn btn-outline-dark" >SUBMIT</button>
      
                                    </div>
                                </div>
                            </div>
                          </form>
                        </div>
                    </div>
                  </section>

            <!--Aboutus-->
            <div class="section" id="aboutus">
              <div class="container" id="Aboutus">
                <div class="row">
                  <div class="col-md-6 aboutus-container">
                    <div class="content-section">
                      <div class="title">
                        <h1>About Us</h1>
                      </div>
                      <div class="content">
                        <h3>Sky Estate</h3>
                        <p>We basically provide Information regarding the properties  around the world so our users can easily find the house and have as much information as they can so you guys can buy house without any issues.</p>
                      </div>
                      <div class="social">
                        <a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a>
                        <a href="https://twitter.com/i/flow/login"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.instagram.com/accounts/login/?hl=en"><i class="fab fa-instagram"></i></a>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6 aboutus-container">
                    <div class="image-section">
                      <img src="./images/Blue Abstract Illustrative Real Estate Property Logo.jpg" class="img-fluid" alt="Real Estate Logo">
                    </div>
                  </div>
                </div>
              </div>
            </div>


    
    <!-- Support Us Section -->
    <div class="support-us-section" id="support">
      <div class="container">
          <div class="row">
              <div class="col-md-6" style="padding-top: 120px;">
                  <h1>Support Us</h1>
                  <p>Your support helps us to provide the best services and properties to our clients. By supporting us, you are contributing to a better future for real estate.</p>
                  <p>You can support us by:</p>
                  <ul>
                      <li>Sharing our website with your friends and family.</li>
                      <li>Leaving a positive review on our website.</li>
                      <li>Referring us to potential clients.</li>
                  </ul>
                  <a href="#" class="btn btn-primary">Support Us Now</a>
              </div>
              <div class="col-md-6">
              <div class="image-section">
                  <img src="./images/55 Blair Road _ ONG&ONG Pte Ltd.jpeg" class="img-fluid" alt="Support Us">
              </div>
          </div>
          </div>
      </div>
    </div>

    <footer class="footer bg-dark text-light py-4">
      <div class="container text-center">
        <p>&copy; 2024 Sky Estate Agency</p>
      </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/0457976769.js" crossorigin="anonymous"></script>
    <script>
      // JavaScript code for smooth scrolling
      document.querySelectorAll('a[href^="#"]').forEach(anchor => {
          anchor.addEventListener('click', function (e) {
              e.preventDefault();
    
              document.querySelector(this.getAttribute('href')).scrollIntoView({
                  behavior: 'smooth'
              });
          });
      });
    </script>
</body>

</html>