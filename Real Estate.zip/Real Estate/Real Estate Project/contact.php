<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $message = $_POST['message'];
  
  // You can add more processing here, like sending the email to your inbox
  
  // For demonstration, simply echo the received data
  echo "Name: $name <br>";
  echo "Email: $email <br>";
  echo "Message: $message <br>";
}
?>
