<!DOCTYPE html>
 
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="./images/Blue Abstract Illustrative Real Estate Property Logo.jpg">
    <title>  Sign Up   </title> 
    <link rel="stylesheet" href="style.css">
    <style>/* signup start */
   
        *{
          margin: 0;
          padding: 0;
          box-sizing: border-box;
          font-family: 'Poppins', sans-serif;
        }
        body{
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #4b8ac56c;
        }
        .wrapper {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 100%;
      padding: 20px;
    }
    .logo {
      width: 500px; 
      height: auto; 
    }

    .form-container {
      flex: 1;
      margin-right: 20px; 
    }

    .form-container h2 {
      margin-bottom: 20px;
    }

    .input-box {
      margin-bottom: 20px;
    }

    .input-box input {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    .policy {
      margin-bottom: 20px;
    }

    .policy h3 {
      margin: 0;
    }

    .text {
      text-align: center;
    }

    .text a {
      color: blue;
    }
        .wrapper h2{
          position: relative;
          font-size: 22px;
          font-weight: 600;
          color: #333;
        }
        .wrapper h2::before{
          content: '';
          position: absolute;
          left: 0;
          bottom: 0;
          height: 3px;
          width: 28px;
          border-radius: 12px;
          background: #4070f4;
        }
        .wrapper form{
          margin-top: 30px;
        }
        .wrapper form .input-box{
          height: 52px;
          margin: 18px 0;
        }
        form .input-box input{
          height: 100%;
          width: 100%;
          outline: none;
          padding: 0 15px;
          font-size: 17px;
          font-weight: 400;
          color: #333;
          border: 1.5px solid #C7BEBE;
          border-bottom-width: 2.5px;
          border-radius: 6px;
          transition: all 0.3s ease;
        }
        .input-box input:focus,
        .input-box input:valid{
          border-color: #4070f4;
        }
        form .policy{
          display: flex;
          align-items: center;
        }
        form h3{
          color: #707070;
          font-size: 14px;
          font-weight: 500;
          margin-left: 10px;
        }
        .input-box.button input{
          color: #fff;
          letter-spacing: 1px;
          border: none;
          background: #4070f4;
          cursor: pointer;
        }
        .input-box.button input:hover{
          background: #0e4bf1;
        }
        form .text h3{
         color: #333;
         width: 100%;
         text-align: center;
        }
        form .text h3 a{
          color: #4070f4;
          text-decoration: none;
        }
        form .text h3 a:hover{
          text-decoration: underline;
        }
          /* signup end */</style>
   </head>
<body>
<?php
if(isset($_GET['message'])) {
    $message = $_GET['message'];
    if($message == 'username_exists') {
        echo '<div class="alert alert-danger" role="alert">Username already exists!</div>';
    } elseif($message == 'email_exists') {
        echo '<div class="alert alert-danger" role="alert">Email already exists!</div>';
    } elseif($message == 'passwords_not_match') {
        echo '<div class="alert alert-danger" role="alert">Passwords do not match!</div>';
    }
}
?>
  <div class="wrapper">
    <img src="./images/Logo.png" alt="Logo" class="logo">
    <div class="form-container">
      <h2>Sign Up</h2>
      <form action="signup_logics.php" method="POST">
        <div class="input-box">
          <input type="text" placeholder="Enter your name" name="user" required>
        </div>
        <div class="input-box">
          <input type="text" placeholder="Enter your email" name="email" required>
        </div>
        <div class="input-box">
          <input type="password" placeholder="Create password" name="pass" onclick="togglePassword('pass')" required>
        </div>
        <div class="input-box">
          <input type="password" placeholder="Confirm password" name="cpass" onclick="togglePassword('cpass')" required>
        </div>

        <div id="password-mismatch-error" style="color: red; display: none;">Passwords do not match!</div>

        <div class="policy">
          <input type="checkbox">
          <h3>I accept all terms & condition</h3>
        </div>
        <div class="input-box button">
          <input type="Submit" name="submit" value="Register Now" onclick="return checkPasswordMatch();">
        </div>
        <div class="text">
          <h3>Already have an account? <a href="./login.html">Login now</a></h3>
        </div>
      </form>
    </div>
  </div>


  <script>
function checkPasswordMatch() {
  var password = document.getElementById('pass').value;
  var confirmPassword = document.getElementById('cpass').value;
  if (password !== confirmPassword) {
    document.getElementById('password-mismatch-error').style.display = 'block';
    return false;
  }
  return true;
}
</script>
</body>
</html>