<?php
// Establishing connection to the database
$conn = mysqli_connect("localhost", "root", "", "skyestate");

// Checking the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieving form data
if(isset($_POST['submit'])) {
    $email =  $_POST['email'];
    $password =  $_POST['pass'];
      
    // Trim whitespace from the password
    // $password = trim($password);
    
    // Fetch user from the database based on email
    $sql = "SELECT * FROM `signup` WHERE email='$email'";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) == 1) {
        // User found, verify password
        $row = mysqli_fetch_assoc($result);
        // Debugging: echo out the hashed password retrieved from the database
        // echo $row['password'];
        if(password_verify($password, $row['password'])) {
            // Password is correct, redirect user with success message
            session_start();
            $_SESSION['email'] = $email;
            header("Location: http://localhost/Real Estate/index.php?message=login_success");
            exit();
        } else {
            // Password is incorrect, redirect with error message
            header("Location: http://localhost/Real Estate/login.php?message=incorrect_password");
            exit();
        }
    } else {
        // User not found, redirect with error message
        header("Location: http://localhost/Real Estate/login.php?message=user_not_found");
        exit();
    }
    
}

// Closing the connection
mysqli_close($conn);
?>
